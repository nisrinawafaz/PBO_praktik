/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.task1;

/**
 *
 * @author ASUS
 */
public class Firm {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Staff personnel = new Staff();
        personnel.payday();
    }
    
}
