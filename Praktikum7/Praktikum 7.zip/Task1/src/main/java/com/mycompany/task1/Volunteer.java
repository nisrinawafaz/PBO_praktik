/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.task1;

/**
 *
 * @author ASUS
 */
public class Volunteer extends StaffMember {
    
    public Volunteer(String eName, String eAddress, String ePhone) {
	super(eName, eAddress, ePhone);
	// TODO Auto-generated constructor stub
    }
	
    @Override
    public double pay() {
	return 0.0;
    }
}
